public class MyClass {
    public  static void main(String args[]) {
        Sum obj = new Sum();
        int val = obj.sumCalculate(4,5);
        System.out.println(val);
    }
}
