class Sum{
    private int a;
    private int b;
    public int sumCalculate(int c, int y){
        return c+y;
    }
}